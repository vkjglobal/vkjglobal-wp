<?php
/**
 * Underscore.js template.
 *
 * @package fusion-builder
 */

?>
<script type="text/template" id="fusion-builder-block-module-woo-shortcodes-preview-template">

	<span class="fusion-module-icon fa fa-lg {{ icon_type }}"></span> {{ params.element_content }}

</script>
